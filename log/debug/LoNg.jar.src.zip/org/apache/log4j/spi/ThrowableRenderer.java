package org.apache.log4j.spi;

public abstract interface ThrowableRenderer
{
  public abstract String[] doRender(Throwable paramThrowable);
}


/* Location:              /home/liuwenhua/tools/LoNg(Official)_ALPS/LoNg_v2.1710.5 (2)/LoNg.jar!/org/apache/log4j/spi/ThrowableRenderer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */